jQuery(document).ready(function($) {
    $('nav#menu').mmenu();
});
! function(e) {
    function n() {
        l = !0, d.$wndw = e(window), d.$html = e("html"), d.$body = e("body"), e.each([i, a, o], function(e, n) {
            n.add = function(e) {
                e = e.split(" ");
                for (var t in e) n[e[t]] = n.mm(e[t])
            }
        }), i.mm = function(e) {
            return "mm-" + e
        }, i.add("wrapper menu inline panel nopanel list nolist subtitle selected label spacer current highest hidden opened subopened subopen fullsubopen subclose"), i.umm = function(e) {
            return "mm-" == e.slice(0, 3) && (e = e.slice(3)), e
        }, a.mm = function(e) {
            return "mm-" + e
        }, a.add("parent"), o.mm = function(e) {
            return e + ".mm"
        }, o.add("toggle open close setSelected transitionend webkitTransitionEnd mousedown mouseup touchstart touchmove touchend scroll resize click keydown keyup"), e[t]._c = i, e[t]._d = a, e[t]._e = o, e[t].glbl = d
    }
    var t = "mmenu",
        s = "4.7.1";
    if (!e[t]) {
        var i = {},
            a = {},
            o = {},
            l = !1,
            d = {
                $wndw: null,
                $html: null,
                $body: null
            };
        e[t] = function(n, s, i) {
            this.$menu = n, this.opts = s, this.conf = i, this.vars = {}, "function" == typeof this.___deprecated && this.___deprecated(), this._initMenu(), this._initAnchors(), this._initEvents();
            var a = this.$menu.children(this.conf.panelNodetype);
            for (var o in e[t].addons) e[t].addons[o]._add.call(this), e[t].addons[o]._add = function() {}, e[t].addons[o]._setup.call(this);
            return this._init(a), "function" == typeof this.___debug && this.___debug(), this
        }, e[t].version = s, e[t].addons = {}, e[t].uniqueId = 0, e[t].defaults = {
            classes: "",
            slidingSubmenus: !0,
            onClick: {
                setSelected: !0
            }
        }, e[t].configuration = {
            panelNodetype: "ul, ol, div",
            transitionDuration: 400,
            openingInterval: 25,
            classNames: {
                panel: "Panel",
                selected: "Selected",
                label: "Label",
                spacer: "Spacer"
            }
        }, e[t].prototype = {
            _init: function(n) {
                n = n.not("." + i.nopanel), n = this._initPanels(n);
                for (var s in e[t].addons) e[t].addons[s]._init.call(this, n);
                this._update()
            },
            _initMenu: function() {
                this.opts.offCanvas && this.conf.clone && (this.$menu = this.$menu.clone(!0), this.$menu.add(this.$menu.find("*")).filter("[id]").each(function() {
                    e(this).attr("id", i.mm(e(this).attr("id")))
                })), this.$menu.contents().each(function() {
                    3 == e(this)[0].nodeType && e(this).remove()
                }), this.$menu.parent().addClass(i.wrapper);
                var n = [i.menu];
                n.push(i.mm(this.opts.slidingSubmenus ? "horizontal" : "vertical")), this.opts.classes && n.push(this.opts.classes), this.$menu.addClass(n.join(" "))
            },
            _initPanels: function(n) {
                var t = this;
                this.__findAddBack(n, "ul, ol").not("." + i.nolist).addClass(i.list);
                var s = this.__findAddBack(n, "." + i.list).find("> li");
                this.__refactorClass(s, this.conf.classNames.selected, "selected"), this.__refactorClass(s, this.conf.classNames.label, "label"), this.__refactorClass(s, this.conf.classNames.spacer, "spacer"), s.off(o.setSelected).on(o.setSelected, function(n, t) {
                    n.stopPropagation(), s.removeClass(i.selected), "boolean" != typeof t && (t = !0), t && e(this).addClass(i.selected)
                }), this.__refactorClass(this.__findAddBack(n, "." + this.conf.classNames.panel), this.conf.classNames.panel, "panel"), n.add(this.__findAddBack(n, "." + i.list).children().children().filter(this.conf.panelNodetype).not("." + i.nopanel)).addClass(i.panel);
                var l = this.__findAddBack(n, "." + i.panel),
                    d = e("." + i.panel, this.$menu);
                if (l.each(function() {
                        var n = e(this),
                            s = n.attr("id") || t.__getUniqueId();
                        n.attr("id", s)
                    }), l.each(function() {
                        var n = e(this),
                            s = n.is("ul, ol") ? n : n.find("ul ,ol").first(),
                            o = n.parent(),
                            l = o.children("a, span"),
                            d = o.closest("." + i.panel);
                        if (o.parent().is("." + i.list) && !n.data(a.parent)) {
                            n.data(a.parent, o);
                            var r = e('<a class="' + i.subopen + '" href="#' + n.attr("id") + '" />').insertBefore(l);
                            l.is("a") || r.addClass(i.fullsubopen), t.opts.slidingSubmenus && s.prepend('<li class="' + i.subtitle + '"><a class="' + i.subclose + '" href="#' + d.attr("id") + '">' + l.text() + "</a></li>")
                        }
                    }), this.opts.slidingSubmenus) {
                    var r = this.__findAddBack(n, "." + i.list).find("> li." + i.selected);
                    r.parents("li").removeClass(i.selected).end().add(r.parents("li")).each(function() {
                        var n = e(this),
                            t = n.find("> ." + i.panel);
                        t.length && (n.parents("." + i.panel).addClass(i.subopened), t.addClass(i.opened))
                    }).closest("." + i.panel).addClass(i.opened).parents("." + i.panel).addClass(i.subopened)
                } else {
                    var r = e("li." + i.selected, d);
                    r.parents("li").removeClass(i.selected).end().add(r.parents("li")).addClass(i.opened)
                }
                var u = d.filter("." + i.opened);
                return u.length || (u = l.first()), u.addClass(i.opened).last().addClass(i.current), this.opts.slidingSubmenus && l.not(u.last()).addClass(i.hidden).end().appendTo(this.$menu), l
            },
            _initAnchors: function() {
                var n = this;
                d.$body.on(o.click, "a", function(s) {
                    var a = e(this),
                        l = !1;
                    for (var r in e[t].addons)
                        if (e[t].addons[r]._clickAnchor && (l = e[t].addons[r]._clickAnchor.call(n, a))) break;
                    if (!l) {
                        var u = a.attr("href") || "";
                        if ("#" == u.slice(0, 1)) try {
                            e(u, n.$menu).is("." + i.panel) && (l = !0, e(u).trigger(n.opts.slidingSubmenus ? o.open : o.toggle))
                        } catch (c) {}
                    }
                    if (l && s.preventDefault(), !l && a.is("." + i.list + " > li > a") && !a.is('[rel="external"]') && !a.is('[target="_blank"]')) {
                        n.__valueOrFn(n.opts.onClick.setSelected, a) && a.parent().trigger(o.setSelected);
                        var p = n.__valueOrFn(n.opts.onClick.preventDefault, a, "#" == u.slice(0, 1));
                        p && s.preventDefault(), n.__valueOrFn(n.opts.onClick.blockUI, a, !p) && d.$html.addClass(i.blocking), n.__valueOrFn(n.opts.onClick.close, a, p) && n.$menu.trigger(o.close)
                    }
                })
            },
            _initEvents: function() {
                var n = this;
                this.$menu.on(o.toggle + " " + o.open + " " + o.close, "." + i.panel, function(e) {
                    e.stopPropagation()
                }), this.opts.slidingSubmenus ? this.$menu.on(o.open, "." + i.panel, function() {
                    return n._openSubmenuHorizontal(e(this))
                }) : this.$menu.on(o.toggle, "." + i.panel, function() {
                    var n = e(this);
                    n.trigger(n.parent().hasClass(i.opened) ? o.close : o.open)
                }).on(o.open, "." + i.panel, function() {
                    e(this).parent().addClass(i.opened)
                }).on(o.close, "." + i.panel, function() {
                    e(this).parent().removeClass(i.opened)
                })
            },
            _openSubmenuHorizontal: function(n) {
                if (n.hasClass(i.current)) return !1;
                var t = e("." + i.panel, this.$menu),
                    s = t.filter("." + i.current);
                return t.removeClass(i.highest).removeClass(i.current).not(n).not(s).addClass(i.hidden), n.hasClass(i.opened) ? s.addClass(i.highest).removeClass(i.opened).removeClass(i.subopened) : (n.addClass(i.highest), s.addClass(i.subopened)), n.removeClass(i.hidden).addClass(i.current), setTimeout(function() {
                    n.removeClass(i.subopened).addClass(i.opened)
                }, this.conf.openingInterval), "open"
            },
            _update: function(e) {
                if (this.updates || (this.updates = []), "function" == typeof e) this.updates.push(e);
                else
                    for (var n = 0, t = this.updates.length; t > n; n++) this.updates[n].call(this, e)
            },
            __valueOrFn: function(e, n, t) {
                return "function" == typeof e ? e.call(n[0]) : "undefined" == typeof e && "undefined" != typeof t ? t : e
            },
            __refactorClass: function(e, n, t) {
                return e.filter("." + n).removeClass(n).addClass(i[t])
            },
            __findAddBack: function(e, n) {
                return e.find(n).add(e.filter(n))
            },
            __transitionend: function(e, n, t) {
                var s = !1,
                    i = function() {
                        s || n.call(e[0]), s = !0
                    };
                e.one(o.transitionend, i), e.one(o.webkitTransitionEnd, i), setTimeout(i, 1.1 * t)
            },
            __getUniqueId: function() {
                return i.mm(e[t].uniqueId++)
            }
        }, e.fn[t] = function(s, i) {
            return l || n(), s = e.extend(!0, {}, e[t].defaults, s), i = e.extend(!0, {}, e[t].configuration, i), this.each(function() {
                var n = e(this);
                n.data(t) || n.data(t, new e[t](n, s, i))
            })
        }, e[t].support = {
            touch: "ontouchstart" in window.document
        }
    }
}(jQuery);
! function(e) {
    var t = "mmenu",
        o = "offCanvas";
    e[t].addons[o] = {
        _init: function() {},
        _setup: function() {
            if (this.opts[o]) {
                var e = this,
                    t = this.opts[o],
                    s = this.conf[o];
                "string" != typeof s.pageSelector && (s.pageSelector = "> " + s.pageNodetype), this.vars.opened = !1;
                var p = [n.offcanvas];
                "left" != t.position && p.push(n.mm(t.position)), "back" != t.zposition && p.push(n.mm(t.zposition)), this.$menu.addClass(p.join(" ")).parent().removeClass(n.wrapper), this.setPage(a.$page), this[o + "_initBlocker"](), this[o + "_initWindow"](), this.$menu.on(i.open + " " + i.opening + " " + i.opened + " " + i.close + " " + i.closing + " " + i.closed + " " + i.setPage, function(e) {
                    e.stopPropagation()
                }).on(i.open + " " + i.close + " " + i.setPage, function(t) {
                    e[t.type]()
                }), this.$menu[s.menuInjectMethod + "To"](s.menuWrapperSelector)
            }
        },
        _add: function() {
            n = e[t]._c, s = e[t]._d, i = e[t]._e, n.add("offcanvas slideout modal background opening blocker page"), s.add("style"), i.add("opening opened closing closed setPage"), a = e[t].glbl, a.$allMenus = (a.$allMenus || e()).add(this.$menu)
        },
        _clickAnchor: function(e) {
            if (this.opts[o]) {
                var t = this.$menu.attr("id");
                if (t && t.length && (this.conf.clone && (t = n.umm(t)), e.is('[href="#' + t + '"]'))) return this.open(), !0;
                if (a.$page) {
                    var t = a.$page.attr("id");
                    return t && t.length && e.is('[href="#' + t + '"]') ? (this.close(), !0) : !1
                }
            }
        }
    }, e[t].defaults[o] = {
        position: "left",
        zposition: "back",
        modal: !1,
        moveBackground: !0
    }, e[t].configuration[o] = {
        pageNodetype: "div",
        pageSelector: null,
        menuWrapperSelector: "body",
        menuInjectMethod: "prepend"
    }, e[t].prototype.open = function() {
        if (this.vars.opened) return !1;
        var e = this;
        return this._openSetup(), setTimeout(function() {
            e._openFinish()
        }, this.conf.openingInterval), "open"
    }, e[t].prototype._openSetup = function() {
        var e = this;
        a.$allMenus.not(this.$menu).trigger(i.close), a.$page.data(s.style, a.$page.attr("style") || ""), a.$wndw.trigger(i.resize, [!0]);
        var t = [n.opened];
        this.opts[o].modal && t.push(n.modal), this.opts[o].moveBackground && t.push(n.background), "left" != this.opts[o].position && t.push(n.mm(this.opts[o].position)), "back" != this.opts[o].zposition && t.push(n.mm(this.opts[o].zposition)), this.opts.classes && t.push(this.opts.classes), a.$html.addClass(t.join(" ")), setTimeout(function() {
            e.vars.opened = !0
        }, this.conf.openingInterval), this.$menu.addClass(n.current + " " + n.opened)
    }, e[t].prototype._openFinish = function() {
        var e = this;
        this.__transitionend(a.$page, function() {
            e.$menu.trigger(i.opened)
        }, this.conf.transitionDuration), a.$html.addClass(n.opening), this.$menu.trigger(i.opening)
    }, e[t].prototype.close = function() {
        if (!this.vars.opened) return !1;
        var e = this;
        return this.__transitionend(a.$page, function() {
            e.$menu.removeClass(n.current).removeClass(n.opened), a.$html.removeClass(n.opened).removeClass(n.modal).removeClass(n.background).removeClass(n.mm(e.opts[o].position)).removeClass(n.mm(e.opts[o].zposition)), e.opts.classes && a.$html.removeClass(e.opts.classes), a.$page.attr("style", a.$page.data(s.style)), e.vars.opened = !1, e.$menu.trigger(i.closed)
        }, this.conf.transitionDuration), a.$html.removeClass(n.opening), this.$menu.trigger(i.closing), "close"
    }, e[t].prototype.setPage = function(t) {
        t || (t = e(this.conf[o].pageSelector, a.$body), t.length > 1 && (t = t.wrapAll("<" + this.conf[o].pageNodetype + " />").parent())), t.addClass(n.page + " " + n.slideout), a.$page = t
    }, e[t].prototype[o + "_initWindow"] = function() {
        a.$wndw.on(i.keydown, function(e) {
            return a.$html.hasClass(n.opened) && 9 == e.keyCode ? (e.preventDefault(), !1) : void 0
        });
        var s = 0;
        a.$wndw.on(i.resize, function(e, t) {
            if (t || a.$html.hasClass(n.opened)) {
                var o = a.$wndw.height();
                (t || o != s) && (s = o, a.$page.css("minHeight", o))
            }
        }), e[t].prototype[o + "_initWindow"] = function() {}
    }, e[t].prototype[o + "_initBlocker"] = function() {
        var s = this;
        a.$blck = e('<div id="' + n.blocker + '" class="' + n.slideout + '" />').appendTo(a.$body), a.$blck.off(i.touchstart).on(i.touchstart, function(e) {
            e.preventDefault(), e.stopPropagation(), a.$blck.trigger(i.mousedown)
        }).on(i.mousedown, function(e) {
            e.preventDefault(), a.$html.hasClass(n.modal) || s.close()
        }), e[t].prototype[o + "_initBlocker"] = function() {}
    };
    var n, s, i, a
}(jQuery);
! function(t) {
    var n = "mmenu",
        a = "buttonbars";
    t[n].addons[a] = {
        _init: function(n) {
            this.opts[a], this.conf[a], this.__refactorClass(t("div", n), this.conf.classNames[a].buttonbar, "buttonbar"), t("." + i.buttonbar, n).each(function() {
                var n = t(this),
                    a = n.children().not("input"),
                    o = n.children().filter("input");
                n.addClass(i.buttonbar + "-" + a.length), o.each(function() {
                    var n = t(this),
                        i = a.filter('label[for="' + n.attr("id") + '"]');
                    i.length && n.insertBefore(i)
                })
            })
        },
        _setup: function() {},
        _add: function() {
            i = t[n]._c, o = t[n]._d, r = t[n]._e, i.add("buttonbar"), s = t[n].glbl
        }
    }, t[n].defaults[a] = {}, t[n].configuration.classNames[a] = {
        buttonbar: "Buttonbar"
    };
    var i, o, r, s
}(jQuery);
! function(t) {
    var e = "mmenu",
        n = "counters";
    t[e].addons[n] = {
        _init: function(e) {
            var s = this,
                d = this.opts[n];
            this.conf[n], this.__refactorClass(t("em", e), this.conf.classNames[n].counter, "counter"), d.add && e.each(function() {
                var e = t(this).data(o.parent);
                e && (e.find("> em." + a.counter).length || e.prepend(t('<em class="' + a.counter + '" />')))
            }), d.update && e.each(function() {
                var e = t(this),
                    n = e.data(o.parent);
                if (n) {
                    var d = n.find("> em." + a.counter);
                    d.length && (e.is("." + a.list) || (e = e.find("> ." + a.list)), e.length && !e.data(o.updatecounter) && (e.data(o.updatecounter, !0), s._update(function() {
                        var t = e.children().not("." + a.label).not("." + a.subtitle).not("." + a.hidden).not("." + a.search).not("." + a.noresultsmsg);
                        d.html(t.length)
                    })))
                }
            })
        },
        _setup: function() {
            var a = this.opts[n];
            "boolean" == typeof a && (a = {
                add: a,
                update: a
            }), "object" != typeof a && (a = {}), a = t.extend(!0, {}, t[e].defaults[n], a), this.opts[n] = a
        },
        _add: function() {
            a = t[e]._c, o = t[e]._d, s = t[e]._e, a.add("counter search noresultsmsg"), o.add("updatecounter"), d = t[e].glbl
        }
    }, t[e].defaults[n] = {
        add: !1,
        update: !1
    }, t[e].configuration.classNames[n] = {
        counter: "Counter"
    };
    var a, o, s, d
}(jQuery);
! function(e) {
    function t(e, t, n) {
        return t > e && (e = t), e > n && (e = n), e
    }
    var n = "mmenu",
        o = "dragOpen";
    e[n].addons[o] = {
        _init: function() {},
        _setup: function() {
            if (this.opts.offCanvas) {
                var s = this,
                    p = this.opts[o],
                    d = this.conf[o];
                if ("boolean" == typeof p && (p = {
                        open: p
                    }), "object" != typeof p && (p = {}), p = e.extend(!0, {}, e[n].defaults[o], p), p.open) {
                    if (Hammer.VERSION < 2) return;
                    var f, c, h, m, u = {},
                        g = 0,
                        l = !1,
                        v = !1,
                        _ = 0,
                        w = 0;
                    switch (this.opts.offCanvas.position) {
                        case "left":
                        case "right":
                            u.events = "panleft panright", u.typeLower = "x", u.typeUpper = "X", v = "width";
                            break;
                        case "top":
                        case "bottom":
                            u.events = "panup pandown", u.typeLower = "y", u.typeUpper = "Y", v = "height"
                    }
                    switch (this.opts.offCanvas.position) {
                        case "left":
                        case "top":
                            u.negative = !1;
                            break;
                        case "right":
                        case "bottom":
                            u.negative = !0
                    }
                    switch (this.opts.offCanvas.position) {
                        case "left":
                            u.open_dir = "right", u.close_dir = "left";
                            break;
                        case "right":
                            u.open_dir = "left", u.close_dir = "right";
                            break;
                        case "top":
                            u.open_dir = "down", u.close_dir = "up";
                            break;
                        case "bottom":
                            u.open_dir = "up", u.close_dir = "down"
                    }
                    var b = this.__valueOrFn(p.pageNode, this.$menu, r.$page);
                    "string" == typeof b && (b = e(b));
                    var y = r.$page;
                    switch (this.opts.offCanvas.zposition) {
                        case "front":
                            y = this.$menu;
                            break;
                        case "next":
                            y = y.add(this.$menu)
                    }
                    var $ = new Hammer(b[0], p.vendors.hammer);
                    $.on("panstart", function(e) {
                        switch (m = e.center[u.typeLower], s.opts.offCanvas.position) {
                            case "right":
                            case "bottom":
                                m >= r.$wndw[v]() - p.maxStartPos && (g = 1);
                                break;
                            default:
                                m <= p.maxStartPos && (g = 1)
                        }
                        l = u.open_dir
                    }).on(u.events + " panend", function(e) {
                        g > 0 && e.preventDefault()
                    }).on(u.events, function(e) {
                        if (f = e["delta" + u.typeUpper], u.negative && (f = -f), f != _ && (l = f >= _ ? u.open_dir : u.close_dir), _ = f, _ > p.threshold && 1 == g) {
                            if (r.$html.hasClass(a.opened)) return;
                            g = 2, s._openSetup(), s.$menu.trigger(i.opening), r.$html.addClass(a.dragging), w = t(r.$wndw[v]() * d[v].perc, d[v].min, d[v].max)
                        }
                        2 == g && (c = t(_, 10, w) - ("front" == s.opts.offCanvas.zposition ? w : 0), u.negative && (c = -c), h = "translate" + u.typeUpper + "(" + c + "px )", y.css({
                            "-webkit-transform": "-webkit-" + h,
                            transform: h
                        }))
                    }).on("panend", function() {
                        2 == g && (r.$html.removeClass(a.dragging), y.css("transform", ""), s[l == u.open_dir ? "_openFinish" : "close"]()), g = 0
                    })
                }
            }
        },
        _add: function() {
            return "function" != typeof Hammer ? (e[n].addons[o]._init = function() {}, e[n].addons[o]._setup = function() {}, void 0) : (a = e[n]._c, s = e[n]._d, i = e[n]._e, a.add("dragging"), r = e[n].glbl, void 0)
        }
    }, e[n].defaults[o] = {
        open: !1,
        maxStartPos: 100,
        threshold: 50,
        vendors: {
            hammer: {}
        }
    }, e[n].configuration[o] = {
        width: {
            perc: .8,
            min: 140,
            max: 440
        },
        height: {
            perc: .8,
            min: 140,
            max: 880
        }
    };
    var a, s, i, r
}(jQuery);
! function(o) {
    var t = "mmenu",
        s = "fixedElements";
    o[t].addons[s] = {
        _init: function() {
            if (this.opts.offCanvas) {
                var t = o("div, span, a", e.$page),
                    d = this.__refactorClass(t, this.conf.classNames[s].fixedTop, "fixed-top"),
                    i = this.__refactorClass(t, this.conf.classNames[s].fixedBottom, "fixed-bottom");
                d.add(i).appendTo(e.$body).addClass(a.slideout)
            }
        },
        _setup: function() {},
        _add: function() {
            a = o[t]._c, d = o[t]._d, i = o[t]._e, a.add("fixed-top fixed-bottom"), e = o[t].glbl
        }
    }, o[t].defaults[s] = {}, o[t].configuration.classNames[s] = {
        fixedTop: "FixedTop",
        fixedBottom: "FixedBottom"
    };
    var a, d, i, e
}(jQuery);
! function(t) {
    var o = "mmenu",
        e = "footer";
    t[o].addons[e] = {
        _init: function(a) {
            var d = this,
                i = this.opts[e],
                r = t("div." + n.footer, this.$menu);
            r.length && (i.update && a.each(function() {
                var o = t(this),
                    a = t("." + d.conf.classNames[e].panelFooter, o),
                    u = a.html();
                u || (u = i.title);
                var l = function() {
                    r[u ? "show" : "hide"](), r.html(u)
                };
                o.on(s.open, l), o.hasClass(n.current) && l()
            }), t[o].addons.buttonbars && t[o].addons.buttonbars._init.call(this, r))
        },
        _setup: function() {
            var a = this.opts[e];
            if ("boolean" == typeof a && (a = {
                    add: a,
                    update: a
                }), "object" != typeof a && (a = {}), a = t.extend(!0, {}, t[o].defaults[e], a), this.opts[e] = a, a.add) {
                var s = a.content ? a.content : a.title;
                t('<div class="' + n.footer + '" />').appendTo(this.$menu).append(s), this.$menu.addClass(n.hasfooter)
            }
        },
        _add: function() {
            n = t[o]._c, a = t[o]._d, s = t[o]._e, n.add("footer hasfooter"), d = t[o].glbl
        }
    }, t[o].defaults[e] = {
        add: !1,
        content: !1,
        title: "",
        update: !1
    }, t[o].configuration.classNames[e] = {
        panelFooter: "Footer"
    };
    var n, a, s, d
}(jQuery);
! function(e) {
    var t = "mmenu",
        a = "header";
    e[t].addons[a] = {
        _init: function(s) {
            var i = this,
                o = this.opts[a],
                l = (this.conf[a], e("." + n.header, this.$menu));
            if (l.length) {
                if (o.update) {
                    var h = l.find("." + n.title),
                        c = l.find("." + n.prev),
                        f = l.find("." + n.next),
                        p = l.find("." + n.close),
                        u = !1;
                    r.$page && (u = "#" + r.$page.attr("id"), p.attr("href", u)), s.each(function() {
                        var t = e(this),
                            s = t.find("." + i.conf.classNames[a].panelHeader),
                            r = t.find("." + i.conf.classNames[a].panelPrev),
                            l = t.find("." + i.conf.classNames[a].panelNext),
                            p = s.html(),
                            u = r.attr("href"),
                            v = l.attr("href"),
                            m = r.html(),
                            b = l.html();
                        p || (p = t.find("." + n.subclose).html()), p || (p = o.title), u || (u = t.find("." + n.subclose).attr("href"));
                        var x = function() {
                            h[p ? "show" : "hide"](), h.html(p), c[u ? "attr" : "removeAttr"]("href", u), c[u || m ? "show" : "hide"](), c.html(m), f[v ? "attr" : "removeAttr"]("href", v), f[v || b ? "show" : "hide"](), f.html(b)
                        };
                        t.on(d.open, x), t.hasClass(n.current) && x()
                    })
                }
                e[t].addons.buttonbars && e[t].addons.buttonbars._init.call(this, l)
            }
        },
        _setup: function() {
            var s = this.opts[a];
            if (this.conf[a], "boolean" == typeof s && (s = {
                    add: s,
                    update: s
                }), "object" != typeof s && (s = {}), "undefined" == typeof s.content && (s.content = ["prev", "title", "next"]), s = e.extend(!0, {}, e[t].defaults[a], s), this.opts[a] = s, s.add) {
                if (s.content instanceof Array) {
                    for (var d = e("<div />"), r = 0, i = s.content.length; i > r; r++) switch (s.content[r]) {
                        case "prev":
                        case "next":
                        case "close":
                            d.append('<a class="' + n[s.content[r]] + '" href="#"></a>');
                            break;
                        case "title":
                            d.append('<span class="' + n.title + '"></span>');
                            break;
                        default:
                            d.append(s.content[r])
                    }
                    d = d.html()
                } else var d = s.content;
                e('<div class="' + n.header + '" />').prependTo(this.$menu).append(d), this.$menu.addClass(n.hasheader)
            }
        },
        _add: function() {
            n = e[t]._c, s = e[t]._d, d = e[t]._e, n.add("header hasheader prev next close title"), r = e[t].glbl
        }
    }, e[t].defaults[a] = {
        add: !1,
        title: "Menu",
        update: !1
    }, e[t].configuration.classNames[a] = {
        panelHeader: "Header",
        panelNext: "Next",
        panelPrev: "Prev"
    };
    var n, s, d, r
}(jQuery);
! function(l) {
    var e = "mmenu",
        s = "labels";
    l[e].addons[s] = {
        _init: function(e) {
            var n = this.opts[s];
            this.__refactorClass(l("li", this.$menu), this.conf.classNames[s].collapsed, "collapsed"), n.collapse && l("." + a.label, e).each(function() {
                var e = l(this),
                    s = e.nextUntil("." + a.label, "." + a.collapsed);
                s.length && (e.children("." + a.subopen).length || (e.wrapInner("<span />"), e.prepend('<a href="#" class="' + a.subopen + " " + a.fullsubopen + '" />')))
            })
        },
        _setup: function() {
            var a = this.opts[s];
            "boolean" == typeof a && (a = {
                collapse: a
            }), "object" != typeof a && (a = {}), a = l.extend(!0, {}, l[e].defaults[s], a), this.opts[s] = a
        },
        _add: function() {
            a = l[e]._c, n = l[e]._d, o = l[e]._e, a.add("collapsed uncollapsed"), t = l[e].glbl
        },
        _clickAnchor: function(l) {
            var e = l.parent();
            if (e.is("." + a.label)) {
                var s = e.nextUntil("." + a.label, "." + a.collapsed);
                return e.toggleClass(a.opened), s[e.hasClass(a.opened) ? "addClass" : "removeClass"](a.uncollapsed), !0
            }
            return !1
        }
    }, l[e].defaults[s] = {
        collapse: !1
    }, l[e].configuration.classNames[s] = {
        collapsed: "Collapsed"
    };
    var a, n, o, t
}(jQuery);
! function(e) {
    function s(e) {
        switch (e) {
            case 9:
            case 16:
            case 17:
            case 18:
            case 37:
            case 38:
            case 39:
            case 40:
                return !0
        }
        return !1
    }
    var n = "mmenu",
        t = "searchfield";
    e[n].addons[t] = {
        _init: function(n) {
            var i = this,
                l = this.opts[t],
                d = this.conf[t];
            if (l.add) {
                switch (l.addTo) {
                    case "menu":
                        var c = this.$menu;
                        break;
                    case "panels":
                        var c = n;
                        break;
                    default:
                        var c = e(l.addTo, this.$menu).filter("." + a.panel)
                }
                c.length && c.each(function() {
                    var s = e(this),
                        n = s.is("." + a.menu) ? d.form ? "form" : "div" : "li";
                    if (!s.children(n + "." + a.search).length) {
                        if (s.is("." + a.menu)) var t = i.$menu,
                            r = "prependTo";
                        else var t = s.children().first(),
                            r = t.is("." + a.subtitle) ? "insertAfter" : "insertBefore";
                        var o = e("<" + n + ' class="' + a.search + '" />');
                        if ("form" == n && "object" == typeof d.form)
                            for (var c in d.form) o.attr(c, d.form[c]);
                        o.append('<input placeholder="' + l.placeholder + '" type="text" autocomplete="off" />'), o[r](t)
                    }
                    l.noResults && (s.is("." + a.menu) && (s = s.children("." + a.panel).first()), n = s.is("." + a.list) ? "li" : "div", s.children(n + "." + a.noresultsmsg).length || e("<" + n + ' class="' + a.noresultsmsg + '" />').html(l.noResults).appendTo(s))
                })
            }
            if (this.$menu.children("." + a.search).length && this.$menu.addClass(a.hassearch), l.search) {
                var h = e("." + a.search, this.$menu);
                h.length && h.each(function() {
                    var n = e(this);
                    if ("menu" == l.addTo) var t = e("." + a.panel, i.$menu),
                        d = i.$menu;
                    else var t = n.closest("." + a.panel),
                        d = t;
                    var c = n.children("input"),
                        h = i.__findAddBack(t, "." + a.list).children("li"),
                        u = h.filter("." + a.label),
                        f = h.not("." + a.subtitle).not("." + a.label).not("." + a.search).not("." + a.noresultsmsg),
                        p = "> a";
                    l.showLinksOnly || (p += ", > span"), c.off(o.keyup + " " + o.change).on(o.keyup, function(e) {
                        s(e.keyCode) || n.trigger(o.search)
                    }).on(o.change, function() {
                        n.trigger(o.search)
                    }), n.off(o.reset + " " + o.search).on(o.reset + " " + o.search, function(e) {
                        e.stopPropagation()
                    }).on(o.reset, function() {
                        n.trigger(o.search, [""])
                    }).on(o.search, function(s, n) {
                        "string" == typeof n ? c.val(n) : n = c.val(), n = n.toLowerCase(), t.scrollTop(0), f.add(u).addClass(a.hidden), f.each(function() {
                            var s = e(this);
                            e(p, s).text().toLowerCase().indexOf(n) > -1 && s.add(s.prevAll("." + a.label).first()).removeClass(a.hidden)
                        }), e(t.get().reverse()).each(function(s) {
                            var n = e(this),
                                t = n.data(r.parent);
                            if (t) {
                                var d = n.add(n.find("> ." + a.list)).find("> li").not("." + a.subtitle).not("." + a.search).not("." + a.noresultsmsg).not("." + a.label).not("." + a.hidden);
                                d.length ? t.removeClass(a.hidden).removeClass(a.nosubresults).prevAll("." + a.label).first().removeClass(a.hidden) : "menu" == l.addTo && (n.hasClass(a.opened) && setTimeout(function() {
                                    t.trigger(o.open)
                                }, 1.5 * (s + 1) * i.conf.openingInterval), t.addClass(a.nosubresults))
                            }
                        }), d[f.not("." + a.hidden).length ? "removeClass" : "addClass"](a.noresults), i._update()
                    })
                })
            }
        },
        _setup: function() {
            var s = this.opts[t];
            this.conf[t], "boolean" == typeof s && (s = {
                add: s,
                search: s
            }), "object" != typeof s && (s = {}), s = e.extend(!0, {}, e[n].defaults[t], s), "boolean" != typeof s.showLinksOnly && (s.showLinksOnly = "menu" == s.addTo), this.opts[t] = s
        },
        _add: function() {
            a = e[n]._c, r = e[n]._d, o = e[n]._e, a.add("search hassearch noresultsmsg noresults nosubresults"), o.add("search reset change"), i = e[n].glbl
        }
    }, e[n].defaults[t] = {
        add: !1,
        addTo: "menu",
        search: !1,
        placeholder: "Search",
        noResults: "No results found."
    }, e[n].configuration[t] = {
        form: !1
    };
    var a, r, o, i
}(jQuery);
! function(e) {
    var t = "mmenu",
        s = "toggles";
    e[t].addons[s] = {
        _init: function(t) {
            var a = this;
            this.opts[s], this.conf[s], this.__refactorClass(e("input", t), this.conf.classNames[s].toggle, "toggle"), this.__refactorClass(e("input", t), this.conf.classNames[s].check, "check"), e("input." + c.toggle + ", input." + c.check, t).each(function() {
                var t = e(this),
                    s = t.closest("li"),
                    l = t.hasClass(c.toggle) ? "toggle" : "check",
                    n = t.attr("id") || a.__getUniqueId();
                s.children('label[for="' + n + '"]').length || (t.attr("id", n), s.prepend(t), e('<label for="' + n + '" class="' + c[l] + '"></label>').insertBefore(s.children("a, span").last()))
            })
        },
        _setup: function() {},
        _add: function() {
            c = e[t]._c, a = e[t]._d, l = e[t]._e, c.add("toggle check"), n = e[t].glbl
        }
    }, e[t].defaults[s] = {}, e[t].configuration.classNames[s] = {
        toggle: "Toggle",
        check: "Check"
    };
    var c, a, l, n
}(jQuery);